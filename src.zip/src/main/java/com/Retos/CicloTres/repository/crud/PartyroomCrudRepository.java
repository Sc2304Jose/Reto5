package com.Retos.CicloTres.repository.crud;

import com.Retos.CicloTres.model.Partyroom;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author Juan Camilo
 */
public interface PartyroomCrudRepository extends CrudRepository<Partyroom, Integer>{
    
}
